#ifndef Car_h
#define Car_h
#include<iostream>
#include <string>

using namespace std;

class Car
{
	private:
		double fuel_level;
		double insurance;
		int total_distance; 
	public:
		Car(double fuel_level, double  insurance, int total_distance);
		void display();

		int gettot() 
		{
			return total_distance;
		}
		void settot(int m)
		{
			total_distance = m;
		}

		double getfuel() 
		{
			return fuel_level;
		}
		void setfuel(double f)
		{
			fuel_level = f;
		}

		double getinsurance() 
		{
			return insurance;
		}
		void setinsurance(double i)
		{
			insurance = i;
		}

};

#endif 