#include "Car.h"
#include "Driver.h"

Car::Car (double fuel_level, double  insurance, int total_distance)
	: fuel_level(300), insurance(1000), total_distance(5000) 
{}

void Car::display()
{
	cout << "Fuel Level: " << fuel_level << endl;
	cout << "Insurance Fee: "<< insurance << endl;
	cout << "Total distance that the car has travelled: " << total_distance << endl;
}
