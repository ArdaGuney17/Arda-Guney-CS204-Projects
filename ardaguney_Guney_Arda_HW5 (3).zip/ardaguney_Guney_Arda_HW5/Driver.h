#ifndef Driver_h
#define Driver_h
#include "Car.h"
#include <string>

using namespace std;

class Driver
{
	private:
		Car& sharedCar;
	public:
		Driver(Car& s_car, double budget);
		double budget;
		void drive(int& km);
		void display();
		void fullFuel();
		void repairCar(string& accidentType);
};
#endif 