#include "Driver.h"

Driver::Driver (Car& s_car, double budget)
	: sharedCar(s_car), budget(1000)
{}

void Driver::drive(int& km)
{
	sharedCar.settot(sharedCar.gettot() + km);

	sharedCar.setfuel(sharedCar.getfuel() - (km/4.0));
}

void Driver::display()
{
	cout << "Driver Budget:" << budget << endl;
}

void Driver::fullFuel()
{
	budget = budget - (300.0 - (sharedCar.getfuel()));
	sharedCar.setfuel(300.0);
	cout << endl;
	cout << "Fuel is full" << endl;
	cout << endl;
}

void Driver::repairCar(string& accidentType)
{
	if (accidentType == "SMALL")
	{
		budget = budget - 50.0;
		sharedCar.setinsurance((sharedCar.getinsurance()) + ((sharedCar.getinsurance()) / 20));
		int abc = 50;
		cout << "50$ is reduced from the driver's budget because of the SMALL accident" << endl;
		cout << "Yearly insurance  fee is increased to " << sharedCar.getinsurance() << " because of the SMALL accident" << endl;
	}
	else if (accidentType == "MEDIUM")
	{
		budget = budget - 150.0;
		sharedCar.setinsurance((sharedCar.getinsurance()) + ((sharedCar.getinsurance()) / 10));
		int abc = 150;
		cout << "150$ is reduced from the driver's budget because of the MEDIUM accident" << endl;
		cout << "Yearly insurance  fee is increased to " << sharedCar.getinsurance() << " because of the MEDIUM accident" << endl;
	}
	else if (accidentType == "LARGE")
	{
		budget = budget - 300.0;
		sharedCar.setinsurance((sharedCar.getinsurance()) + ((sharedCar.getinsurance()) / 5));
		int abc = 300;
		cout << "300$ is reduced from the driver's budget because of the LARGE accident" << endl;
		cout << "Yearly insurance  fee is increased to " << sharedCar.getinsurance() << " because of the LARGE accident" << endl;
	}
}