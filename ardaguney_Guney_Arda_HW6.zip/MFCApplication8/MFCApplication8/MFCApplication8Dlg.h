
// MFCApplication8Dlg.h : header file
//

#pragma once
#include "afxwin.h"


// CMFCApplication8Dlg dialog
class CMFCApplication8Dlg : public CDialogEx
{
// Construction
public:
	CMFCApplication8Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MFCAPPLICATION8_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnEnChangeEdit2();
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnLbnSelchangeList1();
	afx_msg void OnBnClickedButton1();
	int groupedRadioButtons;
	CEdit input1;
	CEdit input2;
	CListBox list;
	CComboBox advanced;
	CEdit bits_input;
	CButton checkShift;
};
