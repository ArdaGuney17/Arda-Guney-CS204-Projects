
// MFCApplication8Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCApplication8.h"
#include "MFCApplication8Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CMFCApplication8Dlg dialog



CMFCApplication8Dlg::CMFCApplication8Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMFCApplication8Dlg::IDD, pParent)
	, groupedRadioButtons(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCApplication8Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO1, groupedRadioButtons);
	DDX_Control(pDX, IDC_EDIT1, input1);
	DDX_Control(pDX, IDC_EDIT2, input2);
	DDX_Control(pDX, IDC_LIST1, list);
	DDX_Control(pDX, IDC_COMBO1, advanced);
	DDX_Control(pDX, IDC_EDIT3, bits_input);
	DDX_Control(pDX, IDC_CHECK1, checkShift);
}

BEGIN_MESSAGE_MAP(CMFCApplication8Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_EDIT1, &CMFCApplication8Dlg::OnEnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT2, &CMFCApplication8Dlg::OnEnChangeEdit2)
	ON_BN_CLICKED(IDC_RADIO1, &CMFCApplication8Dlg::OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO2, &CMFCApplication8Dlg::OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_RADIO3, &CMFCApplication8Dlg::OnBnClickedRadio3)
	ON_BN_CLICKED(IDC_CHECK1, &CMFCApplication8Dlg::OnBnClickedCheck1)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CMFCApplication8Dlg::OnCbnSelchangeCombo1)
	ON_EN_CHANGE(IDC_EDIT3, &CMFCApplication8Dlg::OnEnChangeEdit3)
	ON_LBN_SELCHANGE(IDC_LIST1, &CMFCApplication8Dlg::OnLbnSelchangeList1)
	ON_BN_CLICKED(IDC_BUTTON1, &CMFCApplication8Dlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CMFCApplication8Dlg message handlers

BOOL CMFCApplication8Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	advanced.SetCurSel(0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMFCApplication8Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMFCApplication8Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFCApplication8Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CMFCApplication8Dlg::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.



	// TODO:  Add your control notification handler code here
}


void CMFCApplication8Dlg::OnEnChangeEdit2()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.



	// TODO:  Add your control notification handler code here
}


void CMFCApplication8Dlg::OnBnClickedRadio1()
{
	// TODO: Add your control notification handler code here
	groupedRadioButtons = 0;
}


void CMFCApplication8Dlg::OnBnClickedRadio2()
{
	// TODO: Add your control notification handler code here
	groupedRadioButtons = 1;
}


void CMFCApplication8Dlg::OnBnClickedRadio3()
{
	// TODO: Add your control notification handler code here
	groupedRadioButtons = 2;
}


void CMFCApplication8Dlg::OnBnClickedCheck1()
{
	// TODO: Add your control notification handler code here
	if(checkShift.GetCheck()==1)
	{
		advanced.EnableWindow(TRUE);
		bits_input.EnableWindow(TRUE);
	}
	else
	{
		advanced.EnableWindow(FALSE);
		bits_input.EnableWindow(FALSE);
	}
}


void CMFCApplication8Dlg::OnCbnSelchangeCombo1()
{
	// TODO: Add your control notification handler code here
}


void CMFCApplication8Dlg::OnEnChangeEdit3()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.



	// TODO:  Add your control notification handler code here
}


void CMFCApplication8Dlg::OnLbnSelchangeList1()
{
	// TODO: Add your control notification handler code here
}

int maxSize = 0;
void CMFCApplication8Dlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	CString num1, num2, bit, selectionn, ressult, f_result, oper, fnum1, fnum2;
	unsigned int nums1, nums2, bits, result;
	input1.GetWindowTextW(num1);
	input2.GetWindowTextW(num2);
	bits_input.GetWindowTextW(bit);

	nums1 =  _tcstoul(num1,nullptr,10);
	nums2 =  _tcstoul(num2,nullptr,10);
	bits =  _tcstoul(bit,nullptr,10);
	advanced.GetWindowTextW(selectionn);

	if(groupedRadioButtons == 0)
	{
		oper = "AND";
		if(checkShift.GetCheck()==1)
		{
			if(selectionn == "Left")
			{
				nums1 = nums1<<bits;
				nums2 = nums2<<bits;
			}
			else
			{
				nums1 = nums1>>bits;
				nums2 = nums2>>bits;
			}
			result = nums1&nums2;
		}
		else
		{
			result = nums1&nums2;
		}
		UpdateData(TRUE);
	}
	else if (groupedRadioButtons == 1)
	{
		oper = "OR";
		if(checkShift.GetCheck()==1)
		{
			if(selectionn == "Left")
			{
				nums1 = nums1<<bits;
				nums2 = nums2<<bits;
			}
			else
			{
				nums1 = nums1>>bits;
				nums2 = nums2>>bits;
			}
			result = nums1|nums2;
		}
		else
		{
			result = nums1|nums2;
		}
		UpdateData(TRUE);
	}
	else if (groupedRadioButtons == 2)
	{
		oper = "XOR";
		if(checkShift.GetCheck()==1)
		{
			if(selectionn == "Left")
			{
				nums1 = nums1<<bits;
				nums2 = nums2<<bits;
			}
			else
			{
				nums1 = nums1>>bits;
				nums2 = nums2>>bits;
			}
			result = nums1^nums2;
		}
		else
		{
			result = nums1^nums2;
		}
		UpdateData(TRUE);
	}

		CDC *pDC = GetDC();
		CSize cz;
			CFont *pOldFont = pDC->SelectObject(GetFont());
		fnum1.Format(_T("%u"), nums1);
		fnum2.Format(_T("%u"), nums2);
		ressult.Format(_T("%u"), result);
		f_result = fnum1 + _T(" ") + oper + _T(" ") + fnum2 + _T(" = ") + ressult;
		list.AddString(f_result);
		cz = pDC->GetTextExtent(f_result);
		if(cz.cx > maxSize)
		{
			maxSize = cz.cx; 
		}
		list.SetHorizontalExtent(maxSize);
}

