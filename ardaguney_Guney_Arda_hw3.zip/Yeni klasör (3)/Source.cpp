#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include<iomanip>

using namespace std;

struct busStop 
{
	string busStopName;
	busStop *left;
	busStop *right;
};

busStop* temp_ = NULL;

struct busLine 
{
	string busLineName;
	busLine *next;
	busStop *busStops;
};
busLine* head = NULL;
busLine* temp = NULL;

void printMainMenu()
{
	cout << endl;
	cout <<"I***********************************************I"<<endl
	<<"I 0 - EXIT PROGRAM I"<<endl
	<<"I 1 - PRINT LINES I"<<endl
	<<"I 2 - ADD BUS LINE I"<<endl
	<<"I 3 - ADD BUS STOP I"<<endl
	<<"I 4 - DELETE BUS LINE I"<<endl
	<<"I 5 - DELETE BUS STOP I"<<endl
	<<"I 6 - PATH FINDER I"<<endl
	<<"I***********************************************I"<<endl
	<<">>";
	cout << endl;
}

bool consistencyCheck()
{
	busLine* currBL = head; //a global variable
	while(currBL) 
	{
		busStop* currBS = currBL->busStops;
		while(currBS) 
		{
			busStop* rightBS = currBS->right;
			if(rightBS && rightBS->left != currBS) 
			{
			cout << "Inconsistency for " << currBL->busLineName
				<< " " << currBS->busStopName << endl;
			return false; 
			}
			currBS = currBS->right;
		}
		currBL = currBL->next;
	}
	return true; 
}

void printBusLines()
{
	busLine* pot = head;
	while(pot != NULL)
	{
		cout << pot->busLineName << " " << pot->busStops->busStopName;
		busStop* erd = pot->busStops->right;
		while(erd != NULL)
		{
			cout << "<->" << erd->busStopName;
			erd = erd->right;
		}
		cout << endl;
		pot = pot->next;
	}
}

void addBusLine()
{
	string word,info;
	int nuo = 0;
	int nul = 0;
	cout << "Enter the name of the new bus line (0 for exit to main menu)." << endl;
	cin >> info;
	info += ":";
	if(info != "0:")
	{
		int ur = 0;
		busLine*cd = head;
		while(cd != NULL)
		{
			if (cd->busLineName == word)
			{
				ur = 1;
			}
			cd = cd->next;
		}

		int bo = 0;

		while (word != "0:" & word != "0")
		{
			if (ur != 1)
			{
				if(nul != 1)
				{
					cout << "Enter the name of the next bus stop (enter 0 to complete)" << endl;
					cin >> word;
					bo++;
				}
				if (word != "0")
				{
					if(nuo == 0)
					{
						temp = new busLine();
						temp-> busLineName = info;
						temp->next = head;
						head = temp;
						temp->busStops = new busStop;
						temp->busStops->left = NULL;
						temp->busStops->right = NULL;
					}
					nuo++;

					busLine* por = head;
					busStop* bspor = por->busStops;
					int tc = 0;
					while (bspor != NULL)
					{
						if(bspor->busStopName == word)
						{
							tc = 1;
						}
						bspor = bspor->right;
					}
					if (tc != 1)
					{
							nul = 0;
							temp_ = new busStop();
							temp_-> busStopName = word;
							temp_->right = NULL;
							temp_->left = NULL;
							busLine* ptr = head;

							if(ptr->busStops == NULL)
							{
								ptr->busStops = new busStop();
									ptr->busStops->busStopName = word;
								temp_->right = NULL;
								temp_->left = NULL;
							}
							else
							{
								busStop* busStop_ptr = ptr->busStops;
								cout << ptr->busStops->busStopName;
								while(busStop_ptr->right != NULL)
								{
									busStop_ptr = busStop_ptr->right;
								}
								busStop_ptr->right = temp_;
								temp_->left = busStop_ptr;
							}	
					}
					else
					{
						cout << "Bus stop already exists in the line" << endl;
						cout << "Enter the name of the next bus stop (enter 0 to complete)" << endl;
						cin >> word;
						tc = 0;
						nul = 1;
					}
				}
				else if (word ==  "0" & bo == 1)
				{
					cout << "You are not allowed to add an empty bus line" << endl;
				}
			}
			else
			{
				cout << "Bus line already exists: enter a new one (0 for exit)" << endl;
				cin >> word;
				ur = 0;
			}
		}
		while(word != "0" || bo > 1 )
		{
			cout << "The bus line information is shown below" << endl;
			cout << head->busLineName << " "<< head->busStops->busStopName;
			busStop *ptrr = head->busStops->right;
			int blue = 0;
			while(ptrr != NULL)
			{
				if(blue != 0)
				{
					cout << "<->";
				}
				cout << ptrr->busStopName;
				ptrr = ptrr->right;
				blue = 1;
			}
			cout << endl;
			blue = 0;
			cout << "Are you sure? Enter (y/Y) for yes (n/N) for no?" << endl;
			char respond;
			cin >> respond;
			if (respond == 'y' || respond == 'Y')
			{
				busLine*abc = head;
				while(abc != NULL)
				{
					cout << abc->busLineName << " " << abc->busStops->busStopName;
					busStop *ptrr = abc->busStops->right;
					int red = 0;
					while(ptrr != NULL)
					{
						if(red != 0)
						{
							cout << "<->";
						}
						cout << ptrr->busStopName;
						ptrr = ptrr->right;
						red = 1;
					}
					cout << endl;
					abc = abc->next;
					red = 0;
					bo = 1;
				}
			}
			else
			{
				while(respond == 'n' || respond == 'N')
				{
					int yup = 0;
					while (yup == 0 || word != "0")
					{
						if (ur != 1)
						{
							if(nul != 1)
							{
								cout << "Enter the name of the next bus stop (enter 0 to complete)" << endl;
								cin >> word;
							}
							if (word != "0")
							{
								busLine* por = head;
								busStop* bspor = por->busStops;
								int tc = 0;
								while (bspor != NULL)
								{
									if(bspor->busStopName == word)
									{
										tc = 1;
									}
									bspor = bspor->right;
								}
								if (tc != 1)
								{
										nul = 0;
										temp_ = new busStop();
										temp_-> busStopName = word;
										temp_->right = NULL;
										temp_->left = NULL;
										busLine* ptr = head;

										if(ptr->busStops == NULL)
										{
											ptr->busStops = new busStop();
												ptr->busStops->busStopName = word;
											temp_->right = NULL;
											temp_->left = NULL;
										}
										else
										{
											busStop* busStop_ptr = ptr->busStops;
											cout << ptr->busStops->busStopName;
											while(busStop_ptr->right != NULL)
											{
												busStop_ptr = busStop_ptr->right;
											}
											busStop_ptr->right = temp_;
											temp_->left = busStop_ptr;
										}	
								}
								else
								{
									cout << "Bus stop already exists in the line" << endl;
									cout << "Enter the name of the next bus stop (enter 0 to complete)" << endl;
									cin >> word;
									tc = 0;
									nul = 1;
								}
							}
						}
						ur = 0;
						yup = 1;
					}
					cout << "The bus line information is shown below" << endl;
					cout << head->busLineName << " "<< head->busStops->busStopName;
					busStop *ptrr = head->busStops->right;
					int blue = 0;
					while(ptrr != NULL)
					{
						if(blue != 0)
						{
							cout << "<->";
						}
						cout << ptrr->busStopName;
						ptrr = ptrr->right;
						blue = 1;
					}
					cout << endl;
					blue = 0;
					cout << "Are you sure? Enter (y/Y) for yes (n/N) for no?" << endl;
					cin >> respond;
					if (respond == 'y' || respond == 'Y')
					{
						busLine*abc = head;
						while(abc != NULL)
						{
							cout << abc->busLineName << " " << abc->busStops->busStopName;
							busStop *ptrr = abc->busStops->right;
							int red = 0;
							while(ptrr != NULL)
							{
								if(red != 0)
								{
									cout << "<->";
								}
								cout << ptrr->busStopName;
								ptrr = ptrr->right;
								red = 1;
							}
							cout << endl;
							abc = abc->next;
							red = 0;

						}
						bo = 1;
					}
				}
			}
		}
	}
	if(word != "0")
	{
		head->busStops = head ->busStops->right; 
	}
}

void addBusStop()
{
	string word, info, data;
	int ruh = 0;
	cout << "Enter the name of the bus line to insert a new bus stop (0 for main menu)" << endl;
	cin >> word;
	word += ":";
	while(word != "0:")
	{
		cout << "The bus line information is shown below" << endl;
		busLine* ewa = head;
		while(ewa != NULL)
		{
			if(ewa->busLineName == word)
			{
				break;
			}
			ewa = ewa->next;
		}
		if (ruh == 1)
		{
			printBusLines();
			break;
		}
		cout << ewa->busLineName << " "<< ewa->busStops->busStopName << "<->";
		busStop *ptrr = ewa->busStops->right;
		int blue = 0;
		while(ptrr != NULL)
		{
			if(blue != 0)
			{
				cout << "<->";
			}
			cout << ptrr->busStopName;
			ptrr = ptrr->right;
			blue = 1;
		}
		cout << endl;
		blue = 0;

		if(ruh != 1)
		{
			cout << "Enter the name of the new bus stop" << endl;
			cin >> info;
			int def = 0;
			busStop* rfd = ewa->busStops->right;
			while (rfd != NULL)
			{
				if(rfd->busStopName == info)
				{
					def = 1;
					break;
				}
				rfd = rfd->right;
			}
			if (def != 0)
			{
				cout << "Bus stop already exists. Going back to previous menu." << endl;
			}
			else
			{
				int yuh = 0;
				while (yuh != 1)
				{
					cout << "Enter the name of the previous bus stop to put the new one after it (0 to put the new one as the first bus stop)" << endl;
					cin >> data;
					busStop *ptrrr = ewa->busStops->right;
					while(ptrrr != NULL)
					{
						if(ptrrr->busStopName == data || data == "0")
						{
							yuh = 1;
							break;
						}
						ptrrr = ptrrr->right;
					}
					if (yuh == 1)
					{
						if(data == "0")
						{
							busStop* eds = ewa->busStops;
							temp_ = new busStop();
							temp_-> busStopName = info;
							temp_->right = NULL;
							temp_->left = NULL;
							temp_->right = eds;
							eds->left = temp_;
							ewa->busStops = temp_;
							ruh = 1;

						}
						else
						{
							busStop*ops = ewa->busStops->right;
							while(ops != NULL)
							{
								if(ops->busStopName == data)
								{
									if(ops->right != NULL)
									{
										temp_ = new busStop();
										temp_-> busStopName = info;
										temp_->right = NULL;
										temp_->left = NULL;
										ops->right->left = temp_;
										temp_->right = ops->right;
										ops->right = temp_;
										temp_->left = ops;
										ruh = 1;
										break;
									}
									else
									{
										temp_ = new busStop();
										temp_-> busStopName = info;
										temp_->right = NULL;
										temp_->left = NULL;
										ops->right = temp_;
										temp_->left = ops;
										ruh = 1;
										break;
									}
								}
								ops = ops->right;
							}
						}
					}
					else
					{
						cout << "Bus stop does not exist. Typo? Enter again (0 for main menu)" << endl;
					}
				}
			}
		}
	}
}

void deleteBusLine()
{
	string busline;
	int sad = 0;
	int counter = 0;
	cout << "Enter the name of the bus line to delete" << endl;
	cin >> busline;
	busline += ":";
	busLine* ptr = head;
	while (ptr != NULL)
	{
		counter++;
		if(ptr->busLineName == busline)
		{
			sad = 1;
			break;
		}
		ptr = ptr->next;
	}
	if(sad == 1)
	{
		if (counter == 1)
		{
			busLine* dce = head;
			head = head->next;
			delete dce;
		}
		else
		{
			busLine* abc = head;
			for (int i = 0; i < counter-2; i++)
			{
				abc = abc->next;
			}
				busLine*edf = abc->next;
				abc->next = abc->next->next;
				delete edf;
		}
		printBusLines();
	}
	else
	{
		cout << "Bus line cannot be found. Going back to the previous (main) menu." << endl;
	}
}

void deleteBusStop()
{
	string option;
	int sad = 0;
	cout << "Enter the name of the bus line to delete a new bus stop (0 for main menu)" << endl;
	cin >> option;
	option += ":";
	while (option != "0:")
	{

		busLine* ptr = head;
		while (ptr != NULL)
		{
			if(ptr->busLineName == option)
			{
				sad = 1;
				break;
			}
			ptr = ptr->next;
		}
		if(sad == 1)
		{
			cout << "The bus line information is shown below" << endl;
			cout << ptr->busLineName << " " << ptr->busStops->busStopName;
			busStop*abc = ptr->busStops->right;
			while(abc != NULL)
			{
				cout << "<->" << abc->busStopName;
				abc = abc->right;
			}
			cout << endl;
			cout << "Enter the name of the bus stop to delete (0 for main menu)" << endl;
			string choice;
			int happy = 0;
			cin >> choice;
			busStop* ptrr = ptr->busStops;
			int counter = 0;
			while(ptrr != NULL)
			{
				counter++;
				if(ptrr->busStopName == choice)
				{
					happy = 1;
					break;
				}
				ptrr = ptrr ->right;
			}
			if(happy == 1)
			{
				if (counter == 1)
				{
					ptr->busStops = ptr->busStops->right;
					option = "0:";
					printBusLines();
				}
				else
				{
					busStop* abc = ptr->busStops;
					for (int i = 0; i < counter-2; i++)
					{
						abc = abc->right;
					}
					if(abc->right->right != NULL)
					{
						abc->right->right->left = abc;
					}
					busStop* dce = abc->right;
					abc->right = abc->right->right;
					delete dce;
					option = "0:";
					printBusLines();
				}
			}
			else
			{
				cout << "Bus stop cannot be found. Enter the name of the bus stop to delete (0 for main menu)" << endl;
			}
		}
		else
		{
			cout << "Bus line cannot be found. Going back to previous (main) menu." << endl;
			option = "0:";
		}
	}

}

void pathfinder()
{
	string now, go; 
	busLine*ptr = head;
	int c = 0;
	cout << "Where are you now?" << endl;
	cin >> now;
	cout << "Where do you want to go?" << endl;
	cin >> go;

	while(ptr != NULL)
	{
		busStop*ptrr = ptr->busStops;
		while(ptrr != NULL)
		{
			if(ptrr->busStopName == now)
			{
				c++;
				break;
			}
			ptrr = ptrr->right;
		}
		if(c == 1)
		{
			break;
		}
		ptr = ptr->next;
	}
	if(c == 0)
	{
		ptr = head;
	}
	int d = 0;
	busStop*ptrrr = ptr->busStops;
    while(ptrrr != NULL)
	{
		//busStop*ptrrr = ptr->busStops;
		while(ptrrr != NULL)
		{
			if(ptrrr->busStopName == go)
			{
				d++;
				break;
			}
			ptrrr = ptrrr->right;
		}
		if(d == 1)
		{
			break;
		}
		//ptr = ptr->next;
	}
	if(c == 1 & d == 1)
	{
		cout << ptr->busLineName;
		busStop*abc = ptr->busStops;
		int e = 0;
		int f = 0;
		while(abc != NULL)
		{
			if(abc->busStopName == now)
			{
				cout << " " << abc->busStopName;
				e = 1;
			}
			if(e > 1)
			{
				cout << "<->" << abc->busStopName;
			}
			if (abc->busStopName == go)
			{
				int f = 1;
				break;
			}
			e++;
			abc = abc->right;
		}
	}
	else
	{
		cout << "Bus stop does not exist in the table. Going back to previous menu." << endl;
	}

}

void processMainMenu()
{
    char input;
	do
	{
		if(!consistencyCheck())
		{
		    cout << "There are inconsistencies. Exit." << endl;
		    return; 
		}
		printMainMenu();
		cout << "Please enter your option " << endl;
		cin >> input;
		switch (input) 
		{
			case '0':
				cout << "Thanks for using our program" << endl;
				return;
			case '1':
				printBusLines();
				break;
			case '2':
				addBusLine();
				break;
			case '3':
				addBusStop();
				break;
			case '4':
				deleteBusLine();
				break;
			case '5':
				deleteBusStop();
				break;
			case '6':
				pathfinder();
				break;
			default:
				cout << "Invalid option: please enter again" << endl;
		}
	} while(true);
}

int main()
{

	int t = 0;

	string filename, line;
	filename = "busLines.txt";
	ifstream info;
    info.open(filename.c_str());

	while(getline(info, line))
	{
		t = 0;
		istringstream ss(line);
		string word; 
		while (ss >> word) 
		{
			if (t == 0)
			{
				temp = new busLine();
				temp-> busLineName = word;
				temp->next = NULL;
				temp->busStops = new busStop;
				temp->busStops->left = NULL;
				temp->busStops->right = NULL;
				if (head == NULL)
				{
					head = temp;
				}
				else
				{
					busLine* ptr = head;
					while(ptr->next != NULL)
					{
						ptr = ptr->next;
					}
					ptr->next = temp;
				}
			}
			else 
			{
				
				temp_ = new busStop();
				temp_-> busStopName = word;
				temp_->right = NULL;
				temp_->left = NULL;
				busLine* ptr = head;
				while(ptr->next != NULL)
				{
					ptr = ptr->next;
				}
				busStop* busStop_ptr = ptr->busStops;
				if(ptr->busStops == NULL)
				{
					ptr->busStops = new busStop();
					ptr->busStops->busStopName = word;
					temp_->right = NULL;
					temp_->left = NULL;
				}
				else
				{
					busStop* busStop_ptr = ptr->busStops;
					while(busStop_ptr->right != NULL)
					{
						busStop_ptr = busStop_ptr->right;
					}
					temp_->left = busStop_ptr;
					busStop_ptr->right = temp_;
				}	
			}
			t = 1;
		}
	}

	consistencyCheck();

	processMainMenu();

	busLine* qwe = head;
	busLine*qws;
	while (qwe != NULL)
	{
		busStop*cxd = qwe->busStops;
		busStop*pol;
		while(cxd != NULL)
		{
			pol = cxd->right;
			delete cxd;
			cxd = pol;
		}
		qws = qwe->next;
		delete qwe;
		qwe = qws;
	}

	return 0;
}