// Arda Guney - 28997 - ardaguney - Homework-1

#include <iostream>
#include<string>
#include<sstream>
#include<fstream>
#include<vector>
#include<climits>
#include<iomanip>
#include"randgen.h"

using namespace std;

int main()
{

	int row;
	int column;
	int bombs;
	int while1;
	int random1;

	while1 = 0;

	cout << "Give the dimensions of the matrix: " << endl;
	cin >> row >> column;
	
	cout << "How many bombs: " << endl;
	cin >> bombs;
	cout << endl;

	while  (while1 == 0)
	{
		if (bombs < 1 || bombs >= (row*column))
		{
			cout << "The number of bombs can not be greater than the whole number of cells minus one. Please give the number of bombs again: " << endl;
			cin >> bombs; 
			cout << endl;
		}
		else 
		{
			while1 = 1;
		}
	}

	int rowx;
	int columnx;
	int r = 0;
	int d = 0;
	string randlist = "";
	string randmember;
	vector<string> listvector;


	while(r < bombs)
	{
		d = 0;
		RandGen a;
		rowx = a.RandInt(0,row-1);
		RandGen b;
		columnx = b.RandInt(0,column-1);
		randmember = "(" + to_string(rowx) + "," + to_string(columnx) + ")";

		if (r == 0)
		{
			listvector.push_back(randmember);
			r++;
		}
		else
		{
			for (int i = 0; i < listvector.size(); i++)
			{
				if (randmember == listvector[i])
				{
					d = 1;
					i = listvector.size();
				}
			}
			if (d == 0)
			{
				listvector.push_back(randmember);
				r++;
			}
		}
	}

	vector<string> coordinates; 

	vector<vector<string>> game;
	
	for (int i = 0; i < row; i++)
	{
		for (int k = 0; k < column; k++)
		{
			coordinates.push_back("X");
		}

		game.push_back(coordinates);
		coordinates.clear();
	}

	for (int j=0; j < game.size(); j++)
    {   
		for (int k=0; k < game[0].size(); k++)
        {   
			cout << setw(4) << game[j][k];
        }
        cout << endl;
    }

	vector<string> new_coordinates; 

	vector<vector<string>> end_game;

	for (int i = 0; i < row; i++)
	{
		for (int k = 0; k < column; k++)
		{
			new_coordinates.push_back("X");
		}

		end_game.push_back(new_coordinates);
		new_coordinates.clear();
	}

	string row_p;
	string column_p;


	for (int i = 0; i < listvector.size(); i++)
	{
		row_p = listvector[i].substr(1,1);
		column_p = listvector[i].substr(3,1);

		end_game[stoi(row_p)][stoi(column_p)] = "B";
	}

	vector<string> values; 

	vector<vector<string>> bomb_values;

	for (int i = 0; i < row; i++)
	{
		for (int i = 0; i < column; i++)
		{
			values.push_back("0");
		}

		bomb_values.push_back(values);
		values.clear();
	}

	int issue = 0; 
	int b;


	for (int i = 0; i < end_game.size(); i++)
	{
		for (int k = 0; k < end_game[0].size(); k++)
		{
			issue = 0;

	
			if (end_game[i][k] != "B")
			{
              if (i<1 & k<1)
			  {
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i<1 & k>=1 & k < (column-1))
			  {
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i<1 & k == (column-1))
			  {
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i>0 & i<row-1 & k == column-1)
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i == row-1 & k == column-1 )
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i == row-1 & k > 0 & k < column -1)
			  {
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i == row-1 & k == 0)
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i>0 & i<row-1 & k == 0)
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else 
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
			  }
			  
			}
			bomb_values[i][k] = to_string(issue); 
			
			if (end_game[i][k] == "B")
			{
				bomb_values[i][k] = "B";
			}
		}
	}

	vector<string> pure_values; 

	vector<vector<string>> pure_bomb_values;

	for (int i = 0; i < row; i++)
	{
		for (int i = 0; i < column; i++)
		{
			pure_values.push_back("0");
		}

		pure_bomb_values.push_back(pure_values);
		pure_values.clear();
	}

	cout << endl;

	 issue = 0; 


	for (int i = 0; i < end_game.size(); i++)
	{
		for (int k = 0; k < end_game[0].size(); k++)
		{
			issue = 0;
	
              if (i<1 & k<1)
			  {
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i<1 & k>=1 & k < (column-1))
			  {
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i<1 & k == (column-1))
			  {
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i>0 & i<row-1 & k == column-1)
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i == row-1 & k == column-1 )
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i == row-1 & k > 0 & k < column -1)
			  {
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i == row-1 & k == 0)
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
			  }
			  else if (i>0 & i<row-1 & k == 0)
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
			  }
			  else 
			  {
				  if (end_game[i-1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k+1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i+1][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i][k-1] == "B")
				  {
					  issue++;
				  }
				  if (end_game[i-1][k-1] == "B")
				  {
					  issue++;
				  }
			  }
			  
			pure_bomb_values[i][k] = to_string(issue); 
			
		}
	}

	vector<string> needed_values; 

	vector<vector<string>> needed_bomb_values;

	for (int i = 0; i < row; i++)
	{
		for (int k = 0; k < column; k++)
		{
			needed_values.push_back("X");
		}

		needed_bomb_values.push_back(needed_values);
		needed_values.clear();
	}

	for (int i = 0; i < needed_bomb_values.size(); i++)
	{
		for (int k = 0; k < column; k++)
		{
			if (bomb_values[i][k] != "B")
			{
				string c = bomb_values[i][k];
				needed_bomb_values[i][k] = c;
			}
		}
	}

	cout << "Press:" << '\n' << "1. If you want to find out the surrounding of a cell"<<  '\n' << "2. If you want to open the cell" << '\n' << "3. If you want to exit." << endl;

	char option;

	cin >> option;

	int p = 0;

	while(p == 0)
	{
		if (option < 49 || option > 51)
		{
			cout << "Your input is wrong. Please select one of the options: 1, 2 or 3." << endl;
			cin >> option;
		}
		else
		{
			p = 1;
		}
	}
		int ii;
		int kk;
		int tu = 0;

	while (p == 1 & option != '3')
	{
		cout << "Give the coordinates: " << endl;
		cin >> ii >> kk;
		if (ii < 0 || ii > row-1 || kk < 0 || kk > column-1)
		{
			tu = 1;

			while(tu == 1)
			{
				if (ii < 0 || ii > row-1 || kk < 0 || kk > column-1)
				{
					cout << "It is out of range. Please give a valid coordinates: " << endl;
					cin >> ii >> kk;
				}
				else
				{
					tu = 0;
					p = 0;
				}
			}
		}
		else
		{
			p = 0;
		}
	}

	vector<string> real; 

	vector<vector<string>> real_deal;

	for (int i = 0; i < row; i++)
	{
		for (int i = 0; i < column; i++)
		{
			real.push_back("X");
		}

		real_deal.push_back(real);
		real.clear();
	}

	int finish = row*column - bombs;
	int win = 0;
	int i = 0;

	while (i < finish-1)
	{
		if (option == '1')
		{
			real_deal[ii][kk] = pure_bomb_values[ii][kk];

			cout << endl;
			cout << "Displaying the surrounding of (" << ii << "," << kk << "):"  << endl;

			for (int j=0; j < real_deal.size(); j++)
			{   
	   			for (int k=0; k < real_deal[0].size(); k++)
				{   
					cout << setw(4) << real_deal[j][k];
				}
				cout << endl;
			}

			cout << "Around (" << ii << "," << kk << ")" << " you have " << pure_bomb_values[ii][kk] << " bomb(s)" << endl;
			cout << endl;

			real_deal[ii][kk] = "x";

			cout << "Press:" << '\n' << "1. If you want to find out the surrounding of a cell"<<  '\n' << "2. If you want to open the cell" << '\n' << "3. If you want to exit." << endl;
            cin >> option;

			p = 0;

			while(p == 0)
			{
				if (option < 49 || option > 51)
				{
					cout << "Your input is wrong. Please select one of the options: 1, 2 or 3." << endl;
					cin >> option;
				}
				else
				{
					p = 1;
				}
			}

			while (p == 1)
			{
				cout << "Give the coordinates: " << endl;
				cin >> ii >> kk;

				if (ii < 0 || ii > row-1 || kk < 0 || kk > column-1)
				{
					cout << "It is out of range. Please give a valid coordinates: " << endl;
					cin >> ii >> kk;
				}
				else
				{
					p = 0;
				}
			}
		}
		else if (option == '2')
		{
			if (bomb_values[ii][kk] == "B")
			{
				cout << endl;
				cout << "Unfortunately, you stepped on a mine" << '\n' << "Arrangement of mines:" << endl;

				for (int j=0; j < bomb_values.size(); j++)
				{   
	   				for (int k=0; k < bomb_values[0].size(); k++)
					{   
						cout << setw(4) << bomb_values[j][k];
					}
					cout << endl;
				}
				cout << endl;
				cout << ">>>>> Game Over! <<<<<" << endl;
				i = finish;
				win = 1;
			}
			else
			{
				real_deal[ii][kk] = pure_bomb_values[ii][kk];

				cout << endl;
				cout << "Opening cell (" << ii << "," << kk << ")" << " :" << endl;

				for (int j=0; j < real_deal.size(); j++)
				{   
	   				for (int k=0; k < real_deal[0].size(); k++)
					{   
						cout << setw(4) << real_deal[j][k];
					}
					cout << endl;
				}
				cout << endl;
				i++;

				cout << "Press:" << '\n' << "1. If you want to find out the surrounding of a cell"<<  '\n' << "2. If you want to open the cell" << '\n' << "3. If you want to exit." << endl;
				cin >> option;

				p = 0;

				while(p == 0)
				{
					if (option < 49 || option > 51)
					{
						cout << "Your input is wrong. Please select one of the options: 1, 2 or 3." << endl;
						cin >> option;
					}
					else
					{
						p = 1;
					}
				}

				while (p == 1)
				{
					cout << "Give the coordinates: " << endl;
					cin >> ii >> kk;

					if (ii < 0 || ii > row-1 || kk < 0 || kk > column-1)
					{
						cout << "It is out of range. Please give a valid coordinates: " << endl;
						cin >> ii >> kk;
					}
					else
					{
						p = 0;
					}
				}
			}
		}
		else if (option == '3')
		{
			cout << "Program exiting ..." << endl;
			i = finish;
		}
	}

	if (win == 0 & option != '3')
	{
		cout << endl;
		cout << "Opening cell (" << ii << "," << kk << ")" << " :" << endl;

		for (int j=0; j < needed_bomb_values.size(); j++)
		{   
	   		for (int k=0; k < needed_bomb_values[0].size(); k++)
			{   
				cout << setw(4) << needed_bomb_values[j][k];
			}
			cout << endl;
		}

		cout << "Congratulations! All the non-mined cells opened successfully" << endl;
		cout << "You won!" << endl;
		cout << endl;
		cout << ">>>>> Game Over! <<<<<" << endl;
	}

	cin.clear();
	cin.ignore();
	return 0;
}




