//Arda Guney, 28997, ardaguney, homewrk-2

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include<iomanip>

using namespace std;

int main()
{

	struct courseNode
	{
	 string courseCode, courseName;
	 vector<int> studentsAttendingIDs;
	 courseNode * next;
	};

	 courseNode* head = NULL;
	 courseNode* temp = NULL;

	string filename, line;
	
	cout << "Please enter file name: " ;
	cin >> filename;

	ifstream input;
    input.open(filename.c_str());

	while (input.fail())
	{
		cout << "Error: Cannot open file " << filename << endl;
		cout << "Please enter file name: ";
		cin >> filename;
		input.clear();
		input.open(filename.c_str());
	}

	cout << "Successfully opened file CoursesAndStudents.txt" << endl;
	cout << "The linked list is created." << endl;
    cout << "The initial list is:" << endl;

     int t = 0;
	 int q = 0;
	 int w = 1;
	 int k = 0;
	 int u = 0;
	 int d = 0;
	 int y = 0;

	getline(input, line);
	while(input)
	{
		istringstream ss(line);
		string word; 

		if (u == 0)
		{
		temp = new courseNode();
		}

		u = 1;

		if(q==0)
		{
			while (ss >> word) 
			{
				if(t == 0)
				{
					temp-> courseName = word;
				}
				if (t == 1)
				{
					temp-> courseCode = word;
				}
				if (t > 1)
				{
					temp-> studentsAttendingIDs.push_back(stoi(word));
					getline(input, line);
				}
				t++;
			}
		}
		t = 0;
		if (q != 0)
		{
			ss >> word;
			courseNode* P = head;
			while(P != NULL)
			{
					if(P->courseName == word)
					{
						w++;
					}
					if(w == 2)
					{
						ss >> word;
						w++;
					}
					if (w == 3)
					{
						ss >> word;
						P->studentsAttendingIDs.push_back(stoi(word));
						getline(input, line);
						k = 3;
						w = 1;
						d = 1;
						y = 1;
						break;
					}
			  P = P-> next;
		   }

			if (d != 1)
			{
				temp = new courseNode();
			}

			d = 0;

			while (k < 3)
			{
				if (w == 1)
				{
					if(t == 0)
					{
						temp-> courseName = word;
						ss >> word;
					}
					if (t == 1)
					{
						temp-> courseCode = word;
						ss >> word;
					}
					if (t > 1)
					{
						temp-> studentsAttendingIDs.push_back(stoi(word));
						getline(input, line);
						ss >> word;
					}
					t++;
					k++;
				}
			}
			k = 0;
		}

		if (y != 1)
		{
			temp->next = head;
			head = temp;
		}
		y = 0;
		
		t = 0;
		q = 1;
		w = 1;
	}

	courseNode* P = head;
	while(P != NULL)
	{
		cout << P->courseName << " " << P->courseCode << " ";
		for (int i = 0; i < P->studentsAttendingIDs.size() ; i++)
		{
			cout << P->studentsAttendingIDs[i] << " ";
		}
		cout << endl;
		P = P->next;
	}    

	int p = 0;
	while(p == 0)
	{
		cout << endl;
		cout << "Please select one of the choices:" << endl;
		cout << "1. Add to List" << endl;
		cout << "2. Drop from List" << endl;
		cout << "3. Display List" << endl;
		cout << "4. Finish Add/Drop and Exit" << endl;

		string option, choice, info, joe, selection, form, will;
		int mama = 0;
		char letter;
		int g = 0;
		int h = 0;
		int hh = 0;
		int num = 0;
		int ur = 0;
		int um = 0;
		int f = 0;
		int kl = 0;
		int ol = 0;
		int yuk = 0;
		int nut = 1;
		int index;
		cin >> option;

		while (p != 1)
		{
			if(option == "1")
			{
				cout << "Give the student ID and the course names and course codes that he/she wants to add:" << endl;

				getline(cin >> ws, choice);
				choice += " "; 
				int yu = choice.length();

				for (int i = 0; i < choice.length(); i++)
				{
					if(choice[i] == ' ')
					{
						info = choice.substr(g,i-g);
						if (info != "")
						{
							int m = i+1;
							g += (m-g);
							letter = info[0];
							courseNode* A = head;
							if(letter < 48 || letter > 57)
							{
								if (f == 0)
								{
									if (ol == 1)
									{
										temp->next = NULL;
									}
									ol = 0;
					
									mama = 1;
									joe = info;
									ur = 0;
									h = 0;
									courseNode* A = head;
									while(A != NULL)
									{
											if(A->courseName == info)
											{
												h++;
												break;
											}
									  A = A-> next;
									}
									f++;
								}
							}
							else
							{
								if(h > 0)
								{
									 
									courseNode* S = head;
									while(S != NULL)
									{
										if (S->courseName == joe)
										{
											int elon = 0;
											for (int i = 0; i < S->studentsAttendingIDs.size(); i++)
											{
												if(S->studentsAttendingIDs[i] == stoi(info))
												{
													elon = 1;
												}
											}
											if(elon != 1)
											{
												S-> studentsAttendingIDs.push_back(stoi(info));
												cout << "Student with id " << info << " is enrolled to " << joe << "." << endl;
												f = 0;
											}
											else
											{
												cout << "Student with id " << info << " already is enrolled to " << joe << "." << " No action taken." <<endl;
											}
											break;
										}
										S = S-> next;
									}
									f = 0;
								}
							}

							if (h == 0)
							{
								ol = 1;
								if (ur == 0)
								{
									cout << info << " does not exist in the list of Courses. It is added up." << endl;
									yuk ++;
									ol = 1;
									while (temp->next != NULL)
										{
											temp = temp->next;
										}
										temp->next = new courseNode();
										temp = temp ->next;
									ur ++;
									temp-> courseName = info;
								}
								else if (ur == 1)
								{
									ur++;
									temp-> courseCode = info;
								}
								else if (ur > 1)
								{
									int zuk = 0;
									for (int i = 0; i < temp->studentsAttendingIDs.size(); i++)
									{
										if(temp->studentsAttendingIDs[i] == stoi(info))
										{
											zuk = 1;
										}
									}
									if(zuk != 1)
									{
										temp-> studentsAttendingIDs.push_back(stoi(info));
										cout << "Student with id " << info << " is enrolled to " << joe << "." << endl;
										f = 0;
									}
									else
									{
										cout << "Student with id " << info << " already is enrolled to " << joe << "." << " No action taken." <<endl;
									}
								}
							}
						}
					}
				}

					cout << endl;
					cout << "Please select one of the choices:" << endl;
					cout << "1. Add to List" << endl;
					cout << "2. Drop from List" << endl;
					cout << "3. Display List" << endl;
					cout << "4. Finish Add/Drop and Exit" << endl;

					cin >> option;
					choice.clear();
					g = 0;
			}
			else if (option == "2")
			{

				cout << "Give the student ID and the course names and course codes that he/she wants to drop:" << endl; 

				getline(cin >> ws, selection);
				selection += " "; 

				for (int i = 0; i < selection.length(); i++)
				{
					if(selection[i] == ' ')
					{
						form = selection.substr(g,i-g);

						int m = i+1;
						g += (m-g);
						letter = form[0];
						if(letter < 48 || letter > 57)
						{
							if((nut % 2) == 0)
							{
								nut++;
							}
							else
							{
								will = form;
								nut++;
							}
							courseNode* M = head;
							while(M != NULL)
								{
									if (M->courseName == form)
									{
										hh++;
										break;
									}
									M = M-> next;
								}
						}
						else
						{
							if(hh > 0)
							{
								courseNode* L = head;
								while(L != NULL)
								{
									if (L->courseName == will)
									{
										for (int k = 0; k < L->studentsAttendingIDs.size(); k++)
										{
											if(L->studentsAttendingIDs[k] == stoi(form))
											{
												index = 1;
												L->studentsAttendingIDs.erase(L-> studentsAttendingIDs.begin()+k);
												k = L->studentsAttendingIDs.size();
											}
											if(index == 1)
											{
												cout << "Student with id " << form << " has dropped " << will << "." << endl;
												
											}
										}
										if(index == 0)
											{
												cout << "Student with id " << form << " is not enrolled to "<< will <<", thus he can't drop that course." << endl;
											}
										index = 0;
									}
									L = L-> next;
								}
							}
						}
					}
				}

				cout << endl;
				cout << "Please select one of the choices:" << endl;
				cout << "1. Add to List" << endl;
				cout << "2. Drop from List" << endl;
				cout << "3. Display List" << endl;
				cout << "4. Finish Add/Drop and Exit" << endl;

				cin >> option;
				g = 0;
			}
			else if (option == "3")
			{
				if (yuk > 1)
				{
					temp->next = NULL;
				}
				cout << "The current list of course and the students attending them:" << endl;
				courseNode* D = head;
				while(D != NULL)
				{
					
						cout << D->courseName << ": " ;
						for (int i = 0; i < D->studentsAttendingIDs.size() ; i++)
						{
							cout << D->studentsAttendingIDs[i] << " ";
						}
						cout << endl;
					
					D = D->next;
				}

				cout << endl;
				cout << "Please select one of the choices:" << endl;
				cout << "1. Add to List" << endl;
				cout << "2. Drop from List" << endl;
				cout << "3. Display List" << endl;
				cout << "4. Finish Add/Drop and Exit" << endl;

				cin >> option;

			}
			else if (option == "4")
			{
				cout << "The add/drop period is finished. Printing the final list of courses and students attending them." << endl;
				cout << "NOTE: Courses with less than 3 students will be closed this semester." << endl;
				p = 1;
				courseNode* E = head;
				while(E != NULL)
				{
					
						cout << E->courseName ;
						if (E->studentsAttendingIDs.size() >= 3)
						{
							cout << ": ";
							for (int i = 0; i < E->studentsAttendingIDs.size(); i++)
							{
								cout << E->studentsAttendingIDs[i] << " ";
							}
						}
						if (E->studentsAttendingIDs.size() < 3)
						{
							cout <<  " -> This course will be closed";
						}
						cout << endl;
					
					E = E->next;
				}
			}
		}
	}

	cin.clear();
	cin.ignore();
	return 0;
}